import React from 'react'
import Product from '../components/product/Product'
import Header from '../commoncomponents/Header'
import Footer from '../commoncomponents/Footer'

function Product1() {
  return (
    <div>
      <Header/>
      <Product />
      <Footer/>
    </div>
  )
}

export default Product1
